import { Title } from "rizzui/typography";

export default function Home() {
  return (
    <>
      <Title>Isomorphic Stater Template</Title>
    </>
  );
}
