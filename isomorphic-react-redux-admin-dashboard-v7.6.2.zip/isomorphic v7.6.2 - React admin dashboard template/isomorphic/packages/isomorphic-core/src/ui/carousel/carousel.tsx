export { Navigation, Pagination, FreeMode } from 'swiper/modules';
export { Swiper, SwiperSlide } from 'swiper/react';
export type { SwiperOptions } from 'swiper/types';
