export { Portal } from '../Portal/Portal';
export { OptionalPortal } from '../Portal/OptionalPortal';

export type { PortalProps } from '../Portal/Portal';
export type { OptionalPortalProps } from '../Portal/OptionalPortal';
