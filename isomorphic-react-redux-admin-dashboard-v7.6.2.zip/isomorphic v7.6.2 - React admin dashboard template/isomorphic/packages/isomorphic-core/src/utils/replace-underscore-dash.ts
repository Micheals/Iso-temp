export function replaceUnderscoreDash(str: string) {
  return str.replace(/[_-]/g, " ");
}
