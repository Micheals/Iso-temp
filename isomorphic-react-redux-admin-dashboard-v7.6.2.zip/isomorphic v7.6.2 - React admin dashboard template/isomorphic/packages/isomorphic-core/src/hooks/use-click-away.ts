'use client';

export { default as useClickAway } from 'react-use/lib/useClickAway';
