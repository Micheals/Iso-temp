## Isomorphic Starter Template with Internationalization support

**Run the following commands from the packages root**

First install the dependencies by running the following command.

```bash
pnpm install
```

Now to start the local development server run

```bash
pnpm iso:dev
```

To learn more please follow our [Documentation](https://isomorphic-doc.vercel.app/getting-started/installation)
