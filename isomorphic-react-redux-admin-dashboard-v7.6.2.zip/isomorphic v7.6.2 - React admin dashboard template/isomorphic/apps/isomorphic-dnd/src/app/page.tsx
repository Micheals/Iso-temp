import AffiliateDashBoard from "./shared/affiliate/dashboard";

export default function Home() {
  return <AffiliateDashBoard />;
}
