"use client";

export { default as useMedia } from "react-use/lib/useMedia";
